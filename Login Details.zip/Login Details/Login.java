/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**@author lindo
 */
    import java.util.HashMap;
    private final  HashMap<String> userDatabase = new HashMap<>();
    public String registerUser(String username, String password, String phone) {
        boolean validatePhone = checkCellPhoneNumber(phone);
        boolean validateUsername = checkUserName(username);
        boolean validatePassword = checkPasswordComplexity(password);

        if (validatePhone && validateUsername && validatePassword) {
            userDatabase.put(username, password);
            return "User is successfully registered";
        } else {
            return "User registration failed!!!";
        }
    }

    public boolean loginUser(String username, String password) {
        return userDatabase.containsKey(username) && userDatabase.get(username).equals(password);
}
    public Login() {
    }
	public boolean  checkUserName(String username){
		if(username.contains("_") && username.length() <= 5){
			return true;
                        // Username successfully captured
		}
		else{
			return false;
                        // Username is not correctly formatted and please ensure that your username contains and underscore and is no more that five characters long.
		}
	}
	public boolean  checkPasswordComplexity(String password){
		String capital = ".*[A-Z].*";
                    //Checks capital letters
		String small = ".*[a-z].*";
                     //Checks small letters
		String special = ".*[!@#$%^&*(),.?\":{}|<>].*";
                   //Check special characters
		String digit = ".*\\d.*";
                   //Check digit characters
		if(password.length() >= 8 && password.matches(capital) && password.matches(small) 
		&& password.matches(digit) &&password.matches(special)){
			return true;
                        //Password Successfully captured
		}
		else{
			return false;
                        //Password is not correctly formatted, please ensure that the password that you enter must contain at least eight characters, a captital letter, a number, and a special character.
		}
	}
	public boolean  checkCellPhoneNumber(String phone){
		String saCode = "+27";
		String firstThreeChars = phone.substring(0, 3); // Gets characters from index 0 to 2 (inclusive)
		int fourthDigit = Character.getNumericValue(phone.charAt(3));//Gets and convert the fourth digit
		if(phone.length() <= 12 && firstThreeChars.equals(saCode) && fourthDigit >= 6 && fourthDigit <= 8){
			return true;
                        //Cell phone number successfully added
		}
		else{
			return false;
                        //cell phone number incorrectly formatted or does not contain the international code
		}
	}
	public String registerUser(String username, String password, String phone){
		boolean  validatePhone = checkCellPhoneNumber(phone);
                //This step checks and validates the cell phone number
		boolean  validateUsername = checkUserName(username);
                //This checks the username 
		boolean  validatePassword = checkPasswordComplexity(password);
                // the validation of the password if its correct or not
		if(validatePhone == true && validateUsername == true && validatePassword == true){
			return "User is successfully registered";
		}else{
			return "User registration failed!!!!!";
		}
	}
	public boolean loginUser(String username, String password){
		boolean  validUsername = checkUserName(username);
		boolean  validPassword = checkPasswordComplexity(password);
		if(validUsername == true && validPassword == true){
			return true;
		}else{
			return false;
		}
	}
	public String returnLoginStatus(String username, String password){
		boolean  validUsername = checkUserName(username);
		boolean  validPassword = checkPasswordComplexity(password);
		if(validUsername == true && validPassword == true){
			return "A successful login";
		}else{
			return "A failed login";
		}
	}

   
